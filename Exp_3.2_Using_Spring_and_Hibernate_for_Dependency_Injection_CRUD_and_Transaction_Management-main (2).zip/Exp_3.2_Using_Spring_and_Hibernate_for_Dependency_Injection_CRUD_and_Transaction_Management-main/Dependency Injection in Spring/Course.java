

public class Course {
  public String getCourseName() {
    return "Spring & Hibernate";
  }
}
