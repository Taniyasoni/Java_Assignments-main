-- Step 1: Create the database
CREATE DATABASE PRODUCT_REC;

-- Step 2: Use the database
USE PRODUCT_REC;
