create database student_management;

use student_management;

DROP TABLE Student;